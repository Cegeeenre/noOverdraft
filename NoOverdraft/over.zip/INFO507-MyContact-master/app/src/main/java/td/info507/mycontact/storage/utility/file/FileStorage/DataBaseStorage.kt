package td.info507.mycontact.storage.utility.file.FileStorage

import android.content.ContentValues
import android.database.Cursor
import android.database.sqlite.SQLiteOpenHelper
import td.info507.mycontact.storage.utility.Storage

abstract class DataBaseStorage<T>(private val helper: SQLiteOpenHelper, private val table: String) :
    Storage<T> {

    protected abstract fun objectToValues(id: Int, obj: T): ContentValues
    protected abstract fun cursorToObject(cursor: Cursor): T

    override fun insert(obj: T) {

    }

    override fun size(): Int {

    }

    override fun find(id: Int): T? {

    }

    override fun findAll(): List<T> {

    }

    override fun update(id: Int, obj: T) {

    }

    override fun delete(id: Int) {

    }
}