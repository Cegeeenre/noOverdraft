package td.info507.mycontact.storage.utility

import android.content.Context
import java.io.OutputStreamWriter

interface Storage<T> {
    private fun read() {
    }

    private fun write() {

    }

    override fun insert(obj: T) {

    }

    override fun size(): Int {

    }

    override fun find(id: Int): T? {

    }

    override fun findAll(): List<T> {

    }

    override fun update(id: Int, obj: T) {

    }

    override fun delete(id: Int) {

    }
}